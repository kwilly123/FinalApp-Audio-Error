//
//  VC+DocumentExtension.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-06.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation
import Firebase

extension TracksViewController: UIDocumentPickerDelegate {
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        self.attachFiles(audioFile: urls[0])
        projectRef.child("track\(index.row)").updateChildValues(["audio_file" : urls[0].absoluteString])
        
        
        let uploadRef = Storage.storage().reference().child(userID!).child(projectKey!).child("audiofiles").child("track\(index.row)").child("audio.mp3")
        guard let audioData = try? Data(contentsOf: urls[0]) else { return }
        let uploadMetadata = StorageMetadata.init()
        uploadMetadata.contentType = "audio/mp3"
        
        
        DispatchQueue.global(qos: .background).async {
            let taskReference = uploadRef.putData(audioData, metadata: uploadMetadata) { (downloadMetadata, error) in
                if let error = error {
                    print(error.localizedDescription)
                    return
                }
                print("METADATA: \(downloadMetadata)")
            }
            
            taskReference.observe(.progress) { (snapshot) in
                guard let progress = snapshot.progress?.fractionCompleted else { return }
                print("You are \(progress) complete!")
                self.progressLoading.progress = Float(progress)
            }
        }
        
        
        for cell: TrackCell in collectionView!.visibleCells as! [TrackCell] {
            cell.audioPlayer?.stop()
        }
        
        self.scheduleFilesToStart()
        DispatchQueue.main.async {
            self.playButton.setBackgroundImage(UIImage(systemName: "play"), for: .normal)
            self.playButton.isSelected = false
        }
        
        print("\(urls[0])")
        if let cell = collectionView.cellForItem(at: index) as? TrackCell {
            cell.buttonRemove.isEnabled = true
            cell.buttonRemove.alpha = 1.0
            cell.importLight.backgroundColor = .blue
            cell.buttonImport.isEnabled = false
            cell.buttonImport.alpha = 0.5
        }
    }
    
}
