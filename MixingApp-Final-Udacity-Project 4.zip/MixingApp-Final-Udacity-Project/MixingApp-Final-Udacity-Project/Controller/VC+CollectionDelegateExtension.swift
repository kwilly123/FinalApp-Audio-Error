//
//  VC+CollectionDelegateExtension.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-06.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation
import Firebase

extension TracksViewController: UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    //NUMBER OF ITEMS IN COLLECTION
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return tracks.count
    }
    
    //EACH CELL
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "track", for: indexPath) as! TrackCell
        cell.muteDelegate = self
        cell.soloDelegate = self
        cell.trackDelegate = self
        cell.volumeDelegate = self
        cell.panDelegate = self
        
        setupAudioPlayers(audioPlayer: cell.audioPlayer!, indexPath: indexPath)
        
        cell.audioPlayer?.pan = tracks[indexPath.row].pan!
        cell.audioPlayer?.volume = tracks[indexPath.row].volume!
        
        cell.trackLabel.text = "Track \n\(indexPath.row + 1)"
        cell.knob.renderer.setPointerAngle(CGFloat(((tracks[indexPath.row].pan! - -1.0) / (1.0 - -1.0)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
        cell.knob.value = tracks[indexPath.row].pan!
        cell.panValueLabel.text = "\(Int(tracks[indexPath.row].pan! * 100))"
        cell.volumeSlider.value = tracks[indexPath.row].volumeSlider!
        cell.isMuted = tracks[indexPath.row].mute!
        
        
        //SOLO
        cell.isSoloed = tracks[indexPath.row].solo!
        if cell.isSoloed == true {
            cell.soloButton.backgroundColor = .soloYellow
            cell.soloButton.tintColor = .soloYellow
            cell.soloButton.isSelected = true
            soloIndexPath.remove(at: indexPath.row)
            soloIndexPath.insert(indexPath, at: indexPath.row)
        }
        
        
        checkMuteTrack(cell: cell)
        
        return cell
    }
    
    func fetchAudioFile(indexPath: IndexPath) {
        let storageRef = Storage.storage().reference().child(userID!).child(projectKey!).child("audiofiles").child("track\(indexPath.row)").child("audio.mp3")
        let fileManager = FileManager.default
        storageRef.downloadURL { (url, error) in
            if let error = error {
                print(error.localizedDescription)
                return
            }
            
            if let url = url {
                
                if let documentDirectory = try? fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false) {
                    
                    let filePath = documentDirectory.appendingPathComponent(url.lastPathComponent)
                    print("URL: \(url)")
                    
                    guard let audioFileData = try? Data(contentsOf: url) else { return }
                    
                    try? audioFileData.write(to: filePath)

                    var file: AVAudioFile!

                    do {
                        try file = AVAudioFile(forReading: (filePath))
                        print(file.length)
                        self.filesArray.remove(at: indexPath.row)
                        self.filesArray.insert(file, at: indexPath.row)
                        self.scheduleFiles()
                        if let cell = self.collectionView.cellForItem(at: indexPath) as? TrackCell {
                            cell.buttonRemove.isEnabled = true
                            cell.buttonRemove.alpha = 1.0
                            cell.importLight.backgroundColor = .blue
                            cell.buttonImport.isEnabled = false
                            cell.buttonImport.alpha = 0.5
                        }
                    } catch {
                        print(error.localizedDescription)
                    }
                }
            }
        }
    }
    
    //CELL SIZE
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 113, height: 195)
    }
    
    //CELL SELECT
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        trackName.text = "Track \(indexPath.row + 1)"
    }
    
}
