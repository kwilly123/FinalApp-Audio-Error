//
//  Mute.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation

extension TracksViewController: Mute {
    
    func muteButtonTapped(cell: TrackCell) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        print("Track \(indexPath?.row ?? 0) was muted!")
        projectRef.child("track\(indexPath?.row ?? 0)").updateChildValues(["mute" : true])
    }
    
    func muteButtonTappedAgain(cell: TrackCell) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        print("Track \(indexPath?.row ?? 0) was unmuted!")
        projectRef.child("track\(indexPath?.row ?? 0)").updateChildValues(["mute" : false])
    }
    
}
